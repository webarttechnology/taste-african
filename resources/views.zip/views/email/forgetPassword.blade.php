<h1>Forget Password Email</h1>
   
You can reset your password from the link:
<a href="{{ route('password.reset', $token) }}">Reset Password</a>	