<!DOCTYPE html>
<html>
<head>
    <title>Your Email Subject</title>
</head>
<body>
    <h1>Hello!</h1>
    <p>You are Invited as a {{ $role }}  !!</p>
    <a href="https://countrywideprocess.com/new/user-information-register" target="_blank" rel="noopener noreferrer">Click Here to Register </a> 

    <p>Thank you for using our service!</p>
</body>
</html>