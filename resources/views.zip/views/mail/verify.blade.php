<!DOCTYPE html>
<html>
<head>
    <title>Your Email Subject</title>
</head>
<body>
    <h1>Hello!</h1>
    Click the following link to verify your email address:
    <a href="{{url('verify/' . $link)}}">Click Here!</a>
</body>
</html>

